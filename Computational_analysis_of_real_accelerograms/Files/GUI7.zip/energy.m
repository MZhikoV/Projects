function varargout = energy(varargin)
% ENERGY MATLAB code for energy.fig
%      ENERGY, by itself, creates a new ENERGY or raises the existing
%      singleton*.
%
%      H = ENERGY returns the handle to a new ENERGY or the handle to
%      the existing singleton*.
%
%      ENERGY('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ENERGY.M with the given input arguments.
%
%      ENERGY('Property','Value',...) creates a new ENERGY or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before energy_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to energy_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help energy

% Last Modified by GUIDE v2.5 30-Apr-2017 04:25:13

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @energy_OpeningFcn, ...
                   'gui_OutputFcn',  @energy_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before energy is made visible.
function energy_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to energy (see VARARGIN)

% Choose default command line output for energy
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes energy wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = energy_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

global set_content
global  file_name_acc_0 ;
global  file_name_acc_1 ;
global  file_name_acc_2 ;
global  file_name_acc_3 ;
global  file_name_acc_4 ;
global  file_name_acc_5 ;
global  file_name_acc_6 ;
global  file_name_acc_7 ;


if set_content==1
    set(handles.uipanel2,'Visible','off');  
    set(handles.rb_rec_0,'String',file_name_acc_0(1:end-4));
    
else if set_content==7
        
    set(handles.uipanel3,'Visible','off');
    
    set(handles.rb_rec_1,'String',file_name_acc_1(1:end-4))
    set(handles.rb_rec_2,'String',file_name_acc_2(1:end-4))
    set(handles.rb_rec_3,'String',file_name_acc_3(1:end-4))
    set(handles.rb_rec_4,'String',file_name_acc_4(1:end-4))
    set(handles.rb_rec_5,'String',file_name_acc_5(1:end-4))
    set(handles.rb_rec_6,'String',file_name_acc_6(1:end-4))
    set(handles.rb_rec_7,'String',file_name_acc_7(1:end-4))
    end
     
end

















% % % global acc_cm input_dt T_rec Ea EI_H SPV t_Ea_max indx_Ea_max Ea_max
% % % 
% % % %--------------------------------------------------------------------------
% % % %Calculating Energy of acceleration
% % % 
% % % 
% % % Ea = cumtrapz(acc_cm.^2)*input_dt;  %Energy of acceleration defined by Zare
% % % 
% % % 
% % % [Ea_max,indx_Ea_max] = max(abs(Ea)); %peak ground acceleration with index [cm/s^2]
% % % t_Ea_max=T_rec(indx_Ea_max);              %the time in which PGA is located [s]
% % % 
% % % 
% % % 
% % % 
% % % 
% % % %--------------------------------------------------------------------------
% % % %Calculating the Housner(1956) input energy
% % % 
% % % 
% % % EI_H=0.5*SPV.^2;       %Housner(1956) input energy





% --- Executes on button press in pb_plot.
function pb_plot_Callback(hObject, eventdata, handles)
% hObject    handle to pb_plot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global E_type  Ea  indx_Ea_max Ea_max Tn EI_H SPV EI EI_abs acc_cm input_dt t_Ea_max

global set_content

global  T_rec T_rec_0 T_rec_1 T_rec_2 T_rec_3 T_rec_4 T_rec_5 T_rec_6 T_rec_7



%--------------------------------------------------------------------------
%--------------------------------------------------------------------------
%--------------------------------------------------------------------------
%single record
if set_content==1
    
global acc_cm_0 SPV_0  EI_abs_0  EI_0
    
    acc_cm=acc_cm_0;
    SPV=SPV_0;
    EI_abs=EI_abs_0;
    EI=EI_0;
    T_rec=T_rec_0;
    
end


%--------------------------------------------------------------------------
%--------------------------------------------------------------------------
%--------------------------------------------------------------------------
%seven record set

global acc_cm_1 SPV_1  EI_abs_1  EI_1
global acc_cm_2 SPV_2  EI_abs_2  EI_2
global acc_cm_3 SPV_3  EI_abs_3  EI_3
global acc_cm_4 SPV_4  EI_abs_4  EI_4
global acc_cm_5 SPV_5  EI_abs_5  EI_5
global acc_cm_6 SPV_6  EI_abs_6  EI_6
global acc_cm_7 SPV_7  EI_abs_7  EI_7




if set_content==7
 global select_rec; %selected record
switch get(get(handles.uipanel2,'SelectedObject'),'Tag')
      case 'rb_rec_1',  select_rec=1;
      case 'rb_rec_2',  select_rec=2;
      case 'rb_rec_3',  select_rec=3;    
      case 'rb_rec_4',  select_rec=4;    
      case 'rb_rec_5',  select_rec=5;    
      case 'rb_rec_6',  select_rec=6;    
      case 'rb_rec_7',  select_rec=7;    
end


if select_rec==1
    acc_cm=acc_cm_1;
    SPV=SPV_1;
    EI_abs=EI_abs_1;
    EI=EI_1;
    T_rec=T_rec_1;
else if select_rec==2
        acc_cm=acc_cm_2;
        SPV=SPV_2;
        EI_abs=EI_abs_2;
        EI=EI_2;
        T_rec=T_rec_2;
    else if select_rec==3
        acc_cm=acc_cm_3;
        SPV=SPV_3;
        EI_abs=EI_abs_3;
        EI=EI_3;
        T_rec=T_rec_3;
         else if select_rec==4
            acc_cm=acc_cm_4;
            SPV=SPV_4;
            EI_abs=EI_abs_4;
            EI=EI_4;
            T_rec=T_rec_4;
                else if select_rec==5
                    acc_cm=acc_cm_5;
                    SPV=SPV_5;
                    EI_abs=EI_abs_5;
                    EI=EI_5;
                    T_rec=T_rec_5;
                        else if select_rec==6
                            acc_cm=acc_cm_6;
                            SPV=SPV_6;
                            EI_abs=EI_abs_6;
                            EI=EI_6;
                            T_rec=T_rec_6;
                                else if select_rec==7
                                    acc_cm=acc_cm_7;
                                    SPV=SPV_7;
                                    EI_abs=EI_abs_7;
                                    EI=EI_7;
                                    T_rec=T_rec_7;
                                    end
                            end
                    end
             end
        end
    end
end
end

%--------------------------------------------------------------------------
%Calculating Energy of acceleration

Ea = cumtrapz(acc_cm.^2)*input_dt;      %Energy of acceleration defined by Zare

[Ea_max,indx_Ea_max] = max(abs(Ea));    %max energy of acceleration with index
t_Ea_max=T_rec(indx_Ea_max);            %the time in which max energy of acceleration is located [s]


%--------------------------------------------------------------------------
%Calculating the Housner(1956) input energy

EI_H=0.5*SPV.^2;       %Housner(1956) input energy




switch get(get(handles.uipanel1,'SelectedObject'),'Tag')
      case 'radiobutton1',  E_type=1;  
      case 'radiobutton2',  E_type=2;
      case 'radiobutton3',  E_type=3;
      case 'radiobutton4',  E_type=4;
end



if E_type==1
 
    
  plot_x1=T_rec;
    plot_y1=Ea;
    plot_x2=T_rec(indx_Ea_max);
    plot_y2=Ea_max;
    x_label='Time (s)';
    y_label='Ea - Energy of acceleration (Zare,2000)';
    leg_1='Ea';
    leg_2='max Ea';
    strng3 = num2str(Ea_max);
    strng2=strjoin({leg_2,'=', strng3,'cm^2/s^3'});
   
    
axes(handles.axes1);
plot(plot_x1, plot_y1,'b', plot_x2, plot_y2, 'r*');
grid ;
xlabel(x_label);
ylabel(y_label) ;
legend(leg_1, strng2,'Location','east');
% strng = num2str(Ea_max);
% strng1=strjoin({' ','Ea=', strng,'cm^2/s^3','\rightarrow'});
% text(T_rec(indx_Ea_max),Ea_max,  strng1,...
%     'HorizontalAlignment','right');   

elseif E_type==2
    Tn=0:0.01:4;
    plot_x1=Tn;
    plot_y1=EI_H;
    x_label='Period (s)';
    y_label='Input energy - Ei (Housner 1956)';
    axes(handles.axes1);
plot(plot_x1, plot_y1,'b');
grid ;
xlabel(x_label);
ylabel(y_label) ;

elseif E_type==3
    Tn=0:0.01:4;
    plot_x1=Tn;
    plot_y1=abs(EI_abs');
    x_label='Period (s)';
    y_label='Absolute input energy';
    axes(handles.axes1);
plot(plot_x1, plot_y1,'b');
grid ;
xlabel(x_label);
ylabel(y_label) ;


elseif E_type==4
    Tn=0:0.01:4;
    plot_x1=Tn;
    plot_y1=abs(EI');
    x_label='Period (s)';
    y_label='Relative input energy';
    axes(handles.axes1);
plot(plot_x1, plot_y1,'b');
grid ;
xlabel(x_label);
ylabel(y_label) ;


end


% --- Executes on button press in pb_clear.
function pb_clear_Callback(hObject, eventdata, handles)
% hObject    handle to pb_clear (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
axes(handles.axes1);
cla;
xlabel('');
ylabel('') ;
legend('off');

% --- Executes on button press in pb_exit.
function pb_exit_Callback(hObject, eventdata, handles)
% hObject    handle to pb_exit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close all;


% --------------------------------------------------------------------
function Untitled_1_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close;
acc_load_02;

% --------------------------------------------------------------------
function Untitled_2_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close;
time_series;

% --------------------------------------------------------------------
function Untitled_3_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close;
R_spectra;

% --------------------------------------------------------------------
function Untitled_4_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close;
gm_param;


% --------------------------------------------------------------------
function Untitled_5_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close;
Fourier;
